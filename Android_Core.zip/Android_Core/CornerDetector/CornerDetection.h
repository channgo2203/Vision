//
// Created by 김준성 on 2016. 3. 4..
//

#ifndef SIDEWALKDETECTION_CONERDETECTION_H

#include "../default.h"

int cornerDetection2(LineCounts lineCounts);

#endif //SIDEWALKDETECTION_CONERDETECTION_H
