//
// Created by 김준성 on 2016. 2. 26..
//

#ifndef SIDEWALKDETECTION_DEFAULT_H
#define SIDEWALKDETECTION_DEFAULT_H

#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <math.h>

#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>

#include "CornerDetector/ResultLines.h"

using namespace cv;
using namespace std;

#endif //SIDEWALKDETECTION_DEFAULT_H
